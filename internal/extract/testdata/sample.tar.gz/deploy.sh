#!/bin/bash
echo "deploying..."
